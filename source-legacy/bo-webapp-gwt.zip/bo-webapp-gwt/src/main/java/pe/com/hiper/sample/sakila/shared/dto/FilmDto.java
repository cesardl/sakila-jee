package pe.com.hiper.sample.sakila.shared.dto;

import com.google.gwt.user.client.rpc.IsSerializable;

public class FilmDto implements IsSerializable {

}
