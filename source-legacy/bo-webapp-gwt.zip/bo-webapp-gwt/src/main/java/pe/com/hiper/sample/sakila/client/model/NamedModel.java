/**
 * Sencha GXT 3.0.1 - Sencha for GWT
 * Copyright(c) 2007-2012, Sencha, Inc.
 * licensing@sencha.com
 *
 * http://www.sencha.com/products/gxt/license/
 */
package pe.com.hiper.sample.sakila.client.model;

import com.google.gwt.editor.client.Editor.Path;
import com.sencha.gxt.core.client.ValueProvider;
import com.sencha.gxt.data.shared.ModelKeyProvider;
import com.sencha.gxt.data.shared.PropertyAccess;

public class NamedModel {
	public interface NamedModelProperties extends PropertyAccess<NamedModel> {
		@Path("name")
		ModelKeyProvider<NamedModel> kp();

		ValueProvider<NamedModel, String> name();
	}

	private String name;

	protected NamedModel(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
