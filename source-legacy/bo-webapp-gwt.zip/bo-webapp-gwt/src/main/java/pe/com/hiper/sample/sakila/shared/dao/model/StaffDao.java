package pe.com.hiper.sample.sakila.shared.dao.model;

import pe.com.hiper.sample.sakila.shared.dao.SakilaDao;
import pe.com.hiper.sample.sakila.shared.domain.mapping.Staff;

/**
 * 
 * @author pdiaz
 * 
 */
public interface StaffDao extends SakilaDao<Staff> {

}
